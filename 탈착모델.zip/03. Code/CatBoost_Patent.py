import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler, StandardScaler
from catboost import CatBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import matplotlib.pyplot as plt
import optuna
import time

# 코드 시작 시간 기록
start_time = time.time()

# 데이터 로드
data = pd.read_csv('D:\PycharmProjects\LLM\patent\patent_df_re.csv', na_values=["", "NaN"], keep_default_na=False, encoding='utf-8-sig')        ## 경로 수정
data.dropna(inplace=True)
# data = data.drop(columns=['CEC(cmol/g)'])

# 특징(features)와 타겟(target) 분리
X = data.drop(labels =['Desorp effi(%)'], axis=1)
y = data['Desorp effi(%)']
y_copy = data['Desorp effi(%)'].copy()          # 보관용
print(f'X: {X.shape}, y: {y.shape}')            # (313, 8), y: (313,)

# 범주형 변수 식별
categorical_features = X.select_dtypes(include=['object', 'category']).columns
print(f'categorical_features: {categorical_features}')

# 원핫인코딩 적용
encoder = OneHotEncoder(sparse_output=False)
# encoder = OneHotEncoder(sparse_output=False, drop='first')
X_encoded = encoder.fit_transform(X[categorical_features])

# 원핫인코딩된 데이터프레임 생성
X_encoded_df = pd.DataFrame(X_encoded, columns=encoder.get_feature_names_out(categorical_features))

# 원핫인코딩 되지 않은 나머지 특징들과 병합
X = X.drop(categorical_features, axis=1)
X = pd.concat([X, X_encoded_df], axis=1)


# 학습 데이터와 테스트 데이터 분리 (train: 70%, valid: 15%, test: 15%)
X_train_valid, X_test_og, y_train_valid, y_test_og = train_test_split(X, y, test_size=0.15, random_state=90)
X_train_og, X_valid_og, y_train_og, y_valid_og = train_test_split(X_train_valid, y_train_valid, test_size=0.176, random_state=90)
print(f'train.shape: {X_train_og.shape}, val.shape: {X_valid_og.shape}, test.shape: {X_test_og.shape}')

# 데이터 정규화 (train, valid, test 나눈 후 적용)
scaler_X = StandardScaler()
X_train = scaler_X.fit_transform(X_train_og)
X_valid = scaler_X.transform(X_valid_og)
X_test = scaler_X.transform(X_test_og)
#
scaler_y = MinMaxScaler()
y_train = scaler_y.fit_transform(y_train_og.values.reshape(-1, 1))
y_valid = scaler_y.transform(y_valid_og.values.reshape(-1, 1))
y_test = scaler_y.transform(y_test_og.values.reshape(-1, 1))

# 하이퍼파라미터 최적화
def objective_CB(trial: optuna.trial.Trial):
    # Define the hyperparameters to be tuned
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 500, 1500),
        'depth': trial.suggest_int('depth', 1, 6),
        'learning_rate': trial.suggest_float('learning_rate', 0.03, 0.1),
        'l2_leaf_reg': trial.suggest_int('l2_leaf_reg', 5, 15),
        'grow_policy': trial.suggest_categorical('grow_policy', ['SymmetricTree', 'Lossguide', 'Depthwise']),
    }

    # Initialize Random Forest Regressor with the suggested hyperparameters.
    # **params: Input function parameters with dictionary easily. For more information, refere to here: https://brunch.co.kr/@princox/180
    model = CatBoostRegressor(**params, random_state=90, task_type='GPU')

    # Fit the model on the training data
    model.fit(X_train, y_train, eval_set=(X_valid, y_valid), use_best_model=True, verbose=10)

    # Make predictions on the test data
    y_valid_pred = model.predict(X_valid)
    # y_valid_orig = scaler_y.inverse_transform(y_valid)
    # y_valid_pred_orig = scaler_y.inverse_transform(y_valid_pred_scaled.reshape(-1, 1))

    # Evaluate the model using Mean Squared Error
    mse_valid = mean_squared_error(y_valid, y_valid_pred)
    return mse_valid


# Create a study object and optimize hyperparameters using Optuna
study_CB = optuna.create_study(direction='minimize',
                               sampler=optuna.samplers.CmaEsSampler(seed=10, n_startup_trials=1))
study_CB.optimize(objective_CB, n_trials=250)

best_param_CB = study_CB.best_params
print("[Best parameters]\n in {rs}", best_param_CB)

# 가장 좋은 모델 학습
bestmodel = CatBoostRegressor(**best_param_CB, loss_function='RMSE', eval_metric='RMSE', random_state=90, task_type='GPU')
bestmodel.fit(X_train, y_train, eval_set=(X_valid, y_valid), use_best_model=True, verbose=10)
bestmodel.save_model(r'')

# 예측
y_train_pred = bestmodel.predict(X_train)
y_valid_pred = bestmodel.predict(X_valid)
y_test_pred = bestmodel.predict(X_test)

# 비정규화
y_train_orig = scaler_y.inverse_transform(y_train)
y_valid_orig = scaler_y.inverse_transform(y_valid)
y_test_orig = scaler_y.inverse_transform(y_test)

y_train_pred_orig = scaler_y.inverse_transform(y_train_pred.reshape(-1, 1))
y_valid_pred_orig = scaler_y.inverse_transform(y_valid_pred.reshape(-1, 1))
y_test_pred_orig = scaler_y.inverse_transform(y_test_pred.reshape(-1, 1))

# 코드 종료 시간 및 실행 시간 계산
end_time = time.time()
elapsed_time = (end_time - start_time) / 60
print(f'총 실행 시간: {elapsed_time:.2f} 분')

# 모델 저장
bestmodel.save_model(r'D:\PycharmProjects\LLM\patent\Patent_model.cbm')             ## 경로 수정
# 모델 로드
loaded_model = CatBoostRegressor()
loaded_model.load_model(r'D:\PycharmProjects\LLM\patent\Patent_model.cbm')          ## 경로 수정

# results_df = pd.DataFrame(results)
# results_df.to_csv('D:\PycharmProjects\LLM\patent\SY_0707_Standard', index=False, encoding='utf-8-sig')


# Optuna study 최적화 결과를 시각화
import optuna.visualization.matplotlib as opt_viz

def optimization_history(study, font_family="Times New Roman"):
    plt.rcParams["font.family"] = font_family

    # Optimization history plot
    ax1 = opt_viz.plot_optimization_history(study_CB)
    fig1 = plt.gcf()
    fig1.set_size_inches(8, 8)

    fig1.patch.set_facecolor('white')
    ax1.set_facecolor('white')

    # Legend inside plot
    if ax1.get_legend():
        ax1.legend(loc='best', fontsize=18, frameon=True)
        legend1 = ax1.get_legend()
        for text in legend1.get_texts():
            text.set_color('black')
            text.set_fontsize(18)

        frame = legend1.get_frame()
        frame.set(**{'facecolor': 'white', 'edgecolor': 'black',
                     'linewidth': 0.8, 'alpha':0.3})

    # Marker style
    lines = ax1.get_lines()
    for line in lines:
        line.set_markersize(11)  # marker 크기
        line.set_markerfacecolor('royalblue')  # marker 색상
        line.set_markeredgecolor('black')  # marker 테두리 색상

    # Best value line style
    for line in lines:
        if line.get_label() == 'Best Value':
            line.set_color('red')
            line.set_linewidth(2.5)  # 빨간 선 굵기

    # Font sizes + color
    ax1.title.set_fontsize(22)
    ax1.title.set_color('black')
    ax1.xaxis.label.set_fontsize(20)
    ax1.xaxis.label.set_color('black')
    ax1.yaxis.label.set_fontsize(20)
    ax1.yaxis.label.set_color('black')
    ax1.xaxis.label.set_fontweight("bold")
    ax1.yaxis.label.set_fontweight("bold")
    ax1.tick_params(axis='both', labelsize=18, colors='black')

    # 검정 테두리 추가
    for spine in ax1.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1.5)

    ax1.grid(True, color='lightgray', linestyle='--', linewidth=0.8)
    ax1.set_title('')
    plt.tight_layout()
    plt.show()

#  Hyperparameter importance plot
def hyperparam_importance(study, figsize=(8, 8), bar_color='coral'):

    ax = opt_viz.plot_param_importances(study)
    fig = plt.gcf()
    fig.set_size_inches(*figsize)

    # 배경색상
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')

    # 범례 커스터마이징
    legend = ax.get_legend()
    if legend:
        for handle in legend.legend_handles:
            handle.set_color(bar_color)
        for text in legend.get_texts():
            text.set_color('black')
            text.set_fontsize(14)
            text.set_text('Importance')
        legend.set_title(None)
        legend.get_frame().update({'facecolor': 'white',
                                   'edgecolor': 'black',
                                   'linewidth': 0.8,
                                   'alpha': 0.3})
    for text in ax.texts:
        text.set_fontsize(14)
        text.set_color('black')

    ax.title.set_fontsize(22)
    ax.title.set_color('black')
    ax.xaxis.label.set(fontsize=18, color='black', weight='bold')
    ax.yaxis.label.set(fontsize=18, color='black', weight='bold')
    ax.tick_params(axis='both', labelsize=18, colors='black')

    for spine in ax.spines.values():
        spine.set_facecolor('black')
        spine.set_linewidth(1.5)

    ax.grid(True, color='lightgray', linestyle='--', linewidth=0.8)
    ax.set_title(' ')

    plt.tight_layout()
    plt.show()

optimization_history(study_CB)
hyperparam_importance(study_CB)

# 모델 성능 확인
Y_train = np.vstack([y_train_orig, y_valid_orig]).flatten()
Y_train_pred = np.vstack([y_train_pred_orig, y_valid_pred_orig]).flatten()
Y_test, Y_test_pred = y_test_orig.flatten(), y_test_pred_orig.flatten()

MSE_train = mean_squared_error(Y_train, Y_train_pred)
MSE_test = mean_squared_error(Y_test, Y_test_pred)
R2_train = r2_score(Y_train, Y_train_pred)
R2_test = r2_score(Y_test, Y_test_pred)

# Scatter plot
import seaborn as sns
sns.set_style('white')
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12
plt.rcParams['font.weight'] = 'bold'

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 6))

sns.scatterplot(x=Y_train, y=Y_train_pred, ax=ax1, color='#f77f00', marker='o',
                label=f'R2={R2_train:.3f}')
ax1.plot([0, 100], [0, 100], 'r--')
ax1.set_xticks(range(0, 101, 20))
ax1.set_yticks(range(0, 101, 20))
ax1.set_title('Train Prediction')
ax1.set_xlabel('Obs values (%)')
ax1.set_ylabel('Sim values (%)')
ax1.legend()

sns.scatterplot(x=Y_test, y=Y_test_pred, ax=ax2, color='#f77f00', marker='o',
                label=f'R2={R2_test:.3f}')
ax2.plot([0, 100], [0, 100], 'r--')
ax2.set_xticks(range(0, 101, 20))
ax2.set_yticks(range(0, 101, 20))
ax2.set_title('Test Prediction')
ax2.set_xlabel('Obs values (%)')
ax2.set_ylabel('Sim values (%)')
ax2.legend()

for ax in [ax1, ax2]:
    ax.tick_params(axis='both', direction='out', length=6, width=1.5, color='black')
    for spine in ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1.5)

plt.tight_layout()
plt.show()
